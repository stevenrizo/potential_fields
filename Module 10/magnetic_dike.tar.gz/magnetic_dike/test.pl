use Math::Trig;

$ivec = 0.4;
$dvec = 0.01;
$ia = atan2(tan($ivec), sin($dvec));
print "$ia\n";
